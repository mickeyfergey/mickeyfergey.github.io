﻿/*
 * The Super Duper Adventure Game
 * by Mickey Fergus, 2/21/2021
 * 
 * 
 * 
 * The [-] marker in the text is just a cosmetic thing, so I can more easily comments and notes in the code
 *  
 * This work is a derivative of 
 * "C# Adventure Game" by http://programmingisfun.com, used under CC BY.
 * https://creativecommons.org/licenses/by/4.0/
 */

using System;
using System.Collections.Generic;


namespace Adventure
{
    public static class Game
    {

        static int Scenarios = 3; // [-] define number of scenarios for the for loops
        static string CharacterName; // [-] define character name variable
        static string CompanionName; // [-] Define companion
        static string Role;
        public static string Food;
        static List<string> Inventory = new List<string>();



        public static void StartGame() // [-] Run each function for the game here
        {
            GameTitle();
            NameCharacter();
            Choice();
            EndGame();
        }



        // [-] Define game functions below ----------------------------------------------



        // [-] These are the arrays for all the text that will appear on screen.



        // [-] Part 1
        static string[] PartOne = {
            "It's your 8th birthday, and as per tradition, you are now given some way of defending yourself against the dark elves. Do you choose: 1.) Guns, or 2.) Spells and wizardry?",
            "Congratulations Sir Gunslinger, may your bullets be round and your barrels be long or whatever gun people say, I don't know guns.",
            "Wonderful, you can now turn things into cats and play rave music from your magic wand.",
            "Who would you like to be your sidekick? Your options are: 1.) a sentient pangender jar of mayo named Craigory, or 2.) an imaginary shoebox with ADHD named Bo?",
            "Excellent! You and Craigory are the best of friends.",
            "Enjoy your life with your Bo!",
            "You journey on..."
        };


        // [-] Part 2
        static string[] PartTwo = {
            $"You and your trusty companion are walking down a dark alley when a small group of dark elves approaches you, saying that they've been trying to reach you concerning your vehicle's extended warranty. Do you: 1.) buy into their definitley not a scam? or 2.) defend yourself?",
            "Congrats! You are now a proud owner of a 100% real definitely not fake extended warranty on your hover bike! But the elves did a bit more than that...",
            $"You exercise your powers and fight the elves. The scene is not looking good.",
            "You hear the fairy police singing their magical sirens on the way to the crime scene. Do you 1.) mourn the losses and accept responsibilty or 2.) RUN!",
            $"As an honorable warrior, you decide to stay and accept pennance for your actions But you notice that your companion is gone. Where did he go?",
            $"You try to escape, but the singing fairy sirens put you in a trance and you are unable to escape. Even as a mighty warrior, you are unable to escape. However, your companion manages to get away, unaffected by the fairies.",
            "You journey on..."
        };


        // [-] Part 3
        static string[] PartThree = {
            "You sit alone in your prison cell. The guards are bringing dinner, and for your low severity of the crime, given it was self-defense, you're given a choice for dinner! 1.) Smoked applewood sausages with a house salad or 2.) Corned beef and cabbage?",
            $"You enjoy your delicious food.",
            $"You enjoy your delicious food.",
            $"Oh no! You're allergic! What do you do? 1.) Accept your fate and journey into the next life, or 2.) Cry for help?",
            "You come face to face with Foofie, the demi-god who created this world. He says you've been very naughty.",
            $"You scream for help, but it's too late. The epinephrin doesn't circulate through your body in time, and you die at the hands of a plate of meat",
            "The end"
        };


        // A big mess, but this function runs the storyline
        static void Choice()
        {
            for (int section = 1; section <= Scenarios; section++)
            {
                string input = "";

                switch (section)
                {

                    case 1:
                        //Part One

                        // [-] Storyline here
                        Console.WriteLine(PartOne[0]);

                        // [-] Change color
                        Console.ForegroundColor = ConsoleColor.Blue;
                        bool answered = false;
                        

                        while (answered == false)
                        {
                            // [-] Ask for choice
                            Console.Write("Enter your choice: ");
                            input = Console.ReadLine();
                            Console.ResetColor();

                            if (input == "1")
                            {
                                Console.WriteLine(PartOne[1]);
                                Role = "Gunslinger";
                                Inventory.Add("1 Pistol");
                                Inventory.Add("17 Bullets");
                                answered = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartOne[2]);
                                Role = "Wizard";
                                Inventory.Add("1 Magic Wand");
                                Inventory.Add("6 albums of rave music");
                                answered = true;
                            }
                            else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        

                        
                        Console.WriteLine(PartOne[3]);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Enter your choice: ");
                        answered = false;


                        while (answered == false)
                        {
                            input = Console.ReadLine();
                            Console.ResetColor();



                            if (input == "1")
                            {
                                Console.WriteLine(PartOne[4]);
                                CompanionName = "Craigory";
                                Inventory.Add("1 Craigory");
                                answered = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartOne[5]);
                                CompanionName = "Bo";
                                Inventory.Add("1 Bo");
                                answered = true;
                            } else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        

                        
                        Console.WriteLine(PartOne[6]);

                        break;

                    case 2:
                        //Part Two

                        Console.WriteLine(PartTwo[0]);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Enter your choice: ");
                        bool answered2 = false;

                        while (answered2 == false)
                        {
                            input = Console.ReadLine();
                            Console.ResetColor();


                            if (input == "1")
                            {
                                Console.WriteLine(PartTwo[1]);
                                Inventory.Add("1 vehicle's extended warranty");
                                answered2 = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartTwo[2]);
                                Inventory.Add("1 felony");
                                answered2 = true;
                            }
                            else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        

                        Console.WriteLine(PartTwo[3]);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Enter your choice: ");
                        answered2 = false;

                        while (answered2 == false)
                        {
                            input = Console.ReadLine();
                            Console.ResetColor();


                            if (input == "1")
                            {
                                Console.WriteLine(PartTwo[4]);
                                answered2 = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartTwo[5]);
                                answered2 = true;
                            } else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        

                        Console.WriteLine(PartTwo[6]);

                        break;





                    case 3:
                        //Part Three
                        Console.WriteLine(PartThree[0]);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Enter your choice: ");
                        bool answered3 = false;

                        while (answered3 == false)
                        {
                            input = Console.ReadLine();
                            Console.ResetColor();
                            if (input == "1")
                            {
                                Console.WriteLine(PartThree[1]);
                                Food = "Sausage";
                                answered3 = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartThree[2]);
                                Food = "Corned Beef";
                                answered3 = true;
                            } else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        

                        Console.WriteLine(PartThree[3]);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("Enter your choice: ");


                        while (answered3 == false)
                        {
                            input = Console.ReadLine();
                            Console.ResetColor();


                            if (input == "1")
                            {
                                Console.WriteLine(PartThree[4]);
                                answered3 = true;

                            }
                            if (input == "2")
                            {
                                Console.WriteLine(PartThree[5]);
                                answered3 = true;
                            }
                            else
                            {
                                Console.WriteLine("Please enter a proper answer");
                            }
                        }
                        
                        Console.WriteLine(PartThree[6]);
                        break;

                    default:
                        //default if section number does not match one of the above
                        break;
                }

                //let player advance when ready, then clear the screen
                Console.WriteLine("Press enter to continue...");
                Console.ReadKey();
                Console.Clear();

            }
        }




        static void NameCharacter() // [-] Character Naming
        {
            Console.WriteLine("What would you like your character's name to be?");
            CharacterName = Console.ReadLine();

            Console.WriteLine("Splendid! Your Character is now named " + CharacterName);
        }





        static void GameTitle() // [-] Game Cosmetics
        {
            string Title = "Super Duper Adventure Game";
            Console.Title = Title;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine(Title);
            Console.ResetColor();
            Console.WriteLine("Press enter to start");
            Console.ReadKey();
            Console.Clear();
        }





        public static void EndGame()
        {
            //end of game text
            Console.WriteLine("I hope you enjoyed playing!!");
            Console.WriteLine("Congratulations " + CharacterName + "!");

            Console.WriteLine(CharacterName + " you found some items in your journey:");

            foreach (string item in Inventory)
            {
                Console.WriteLine(item);
            }
        }



    }



    class Item
    {

    }
    class Program
    {
        static void Main()
        {
            Game.StartGame();
            Console.Read();
        }

    }
}