﻿using System;
using static System.Console;
namespace _12DaysOfChristmas
{
    public class Verse
    {
        string[] verseArray = new string[]
        {
            "and a partridge in a pear tree.",
            "2 turtle doves,",
            "3 french hens,",
            "4 calling birds,",
            "5 golden rings,",
            "6 geese a laying,",
            "7 swans a swimming",
            "8 maids a milking",
            "9 ladies dancing,",
            "10 lords a leaping,",
            "11 pipers piping,",
            "12 drummers drumming,",

        };

        public void SingTheSong()
        {
            Clear();
            ForegroundColor = ConsoleColor.Green;
            WriteLine("The 12 days of Christmas");
            ForegroundColor = ConsoleColor.Red;
            WriteLine("By: Mickey Fergus");
            ResetColor();


            // This is a separate line given the grammar of the song. The rest follows the function

            WriteLine($"On the 1st day of Christmas, my true love gave to me:");
            WriteLine("A partridge in a pear tree.");
            WriteLine();


            for (int k = 1; k < 12; k++)
            {
                string suffix = "th";
                
                if (k == 1) {
                    suffix = "nd";
                } if (k == 2) {
                    suffix = "rd";
                }
                WriteLine($"On the {k + 1}{suffix} day of Christmas, my true love gave to me:");
                for (int i = k; i >= 0; i--)
                {
                    WriteLine(verseArray[i]);
                }
                WriteLine();
            }

            WriteLine();
            ForegroundColor = ConsoleColor.Blue;
            WriteLine("The end. That's a lotta birds.");
            WriteLine("Also, my brain is soup. This was quite the challenge! However, finishing it felt so rewarding.");
        }
    }
}