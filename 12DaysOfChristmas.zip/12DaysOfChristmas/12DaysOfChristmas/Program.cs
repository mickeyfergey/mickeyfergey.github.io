﻿using System;
using static System.Console;
/*
 * 12 Days of Christmas
 * By Mickey Fergus
 * 2/1/2021
 */

namespace _12DaysOfChristmas
{
    class Program
    {
        static void Main()
        {
            Clear();
            Verse verse = new Verse();
            verse.SingTheSong();
        }
    }
}
