﻿using System;

namespace KeyboardMenuDemo
{
    class Program
    {
        static void Main()
        {
            Game game = new Game();
            game.Start();
        }
    }
}
