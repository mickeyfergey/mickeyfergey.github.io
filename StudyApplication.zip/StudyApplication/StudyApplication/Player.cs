﻿using System;
using static System.Console;

namespace StudyApplication
{
    public class Player
    {
        Utility utility = new Utility();
        string playerName;
        int score;
        

        public void PromptInfo()
        {
            WriteLine("What's your name?");
            playerName = ReadLine();
            Clear();
            WriteLine($"Hi there {playerName}!");
        }


        public void AddPoint()
        {
            score = score + 1;
        }

        public void ShowScore()
        {
            Questions questions = new Questions();
            utility.Green();
            WriteLine($"You have {score} points! Good job!");
            utility.White();
            WriteLine("Press any key to continue");
            ReadKey();
            Clear();

            questions.PromptMenu();
        }

        public void EndTheGame()
        {
            Clear();
            utility.Cyan();
            WriteLine($"Thanks for playing! Hope you had fun and learned something!");
            WriteLine("Study Application: By Mickey Fergus");
            WriteLine("With special thanks to Kyle Hansen for assistance :)");

        }
    }
}
