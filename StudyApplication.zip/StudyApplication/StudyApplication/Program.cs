﻿using System;
using static System.Console;


/*
 * Study Application
 * By: Mickey Fergus
 * 
 * 
 * 
 * 
 * 
 * 
 */

namespace StudyApplication
{
    class Program
    {
        static void Main()
        {
            // Transfer game functionality to game class
            Game.RunGame();
        }

        
    }
}
