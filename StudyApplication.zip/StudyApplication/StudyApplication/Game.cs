﻿using System;
using static System.Console;

namespace StudyApplication
{
    public class Game
    {
        public static void RunGame()
        {
            Utility utility = new Utility();
            // Name console window
            Title = "Study Application by Mickey Fergus";

            // Welcome user
            utility.Green();
            WriteLine("Welcome to the Study Application!");
            ResetColor();

            // Ask user for name
            Player player = new Player();
            Questions questions = new Questions();

            player.PromptInfo();

            // Show tell user how the game works

            WriteLine("Here's how the game works:");
            WriteLine();
            utility.DarkYellow();
            WriteLine("You're going to see a menu like this:");
            ResetColor();
            WriteLine();

            questions.ShowTheMenu();

            WriteLine();
            utility.DarkYellow();
            WriteLine("And you type the corresponding number and then hit enter to select your choice.");
            WriteLine("Are you ready to start? Press any key to begin");
            ResetColor();
            ReadKey();
            Clear();

            questions.PromptMenu();
        }

        public void ShowMenu()
        {
            ForegroundColor = ConsoleColor.DarkBlue;
            WriteLine("================================");
            WriteLine("[1] Round of 15 random questions");
            WriteLine("[2] Check point total");
            WriteLine("[3] Practice the terms");
            WriteLine("[4] Quit the game");
            WriteLine("================================");
            ResetColor();
        }
    }
}