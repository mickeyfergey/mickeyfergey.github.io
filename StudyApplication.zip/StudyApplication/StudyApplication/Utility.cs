﻿using System;
using static System.Console;
namespace StudyApplication
{
    public class Utility
    {
        // Utility class!

        // COLOR METHODS

        public void Red()
        {
            ForegroundColor = ConsoleColor.Red;
        }
        public void Yellow()
        {
            ForegroundColor = ConsoleColor.Yellow;
        }
        public void Green()
        {
            ForegroundColor = ConsoleColor.Green;
        }
        public void Blue()
        {
            ForegroundColor = ConsoleColor.Blue;
        }
        public void Purple()
        {
            ForegroundColor = ConsoleColor.DarkMagenta;
        }
        public void White()
        {
            ForegroundColor = ConsoleColor.White;
        }
        public void RC()
        {
            ForegroundColor = ConsoleColor.White;
        }
        public void Black()
        {
            ForegroundColor = ConsoleColor.Black;
        }
        public void Cyan()
        {
            ForegroundColor = ConsoleColor.Cyan;
        }
        public void DarkCyan()
        {
            ForegroundColor = ConsoleColor.DarkCyan;
        }
        public void DarkBlue()
        {
            ForegroundColor = ConsoleColor.DarkBlue;
        }
        public void DarkGray()
        {
            ForegroundColor = ConsoleColor.DarkGray;
        }
        public void DarkGreen()
        {
            ForegroundColor = ConsoleColor.DarkGreen;
        }
        public void DarkRed()
        {
            ForegroundColor = ConsoleColor.DarkRed;
        }
        public void DarkYellow()
        {
            ForegroundColor = ConsoleColor.DarkYellow;
        }
        public void Gray()
        {
            ForegroundColor = ConsoleColor.Gray;
        }
        public void Magenta()
        {
            ForegroundColor = ConsoleColor.Magenta;
        }

        
    }
}
