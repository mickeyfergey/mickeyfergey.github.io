﻿using System;
using static System.Console;

namespace StudyApplication
{
    public class Questions
    {
        Player player = new Player();
        Game game = new Game();
        Utility utility = new Utility();

        public void ShowTheMenu()
        {
            game.ShowMenu();
        }

        string[] questions = new string[] {
                "The data type that can hold multiple alphanumeric characters is called a:",
                "The data type that can hold one numerical value with NO decimals is called an:",
                "C# is an _______-oriented programming language.",
                "This is sometimes called the blueprint in coding. It holds objects, properties, methods, etc. We call it a:",
                "True and false are values of a _______-type variable.",
                "This is a data type that can hold a multidimensional set of values. It's called an:",
                "This type of loop runs while a variable holds a certain value. It's called a _____ loop",
                "This type of loop runs a given amount of times. It's called a _____ loop",
                "The object 'i++' is another way to ______ an integer.",
                "If you do not want a function to return a value, place ____ before it",
                "To make the function visible to other classes, place _____ before it",
                "A ______ statement uses multiple cases to dermine the outcome.",
                "To create a new _____ of an object, use something like 'Program program = new Program();",
                "This data type can hold decimals, but is not a float",
                "This is a data type that can hold decimals, but is not a double",
                "What letter is used to convert a value to currency?",
        };

        string[] answers = new string[] {
                "string",
                "integer",
                "object",
                "class",
                "boolean",
                "array",
                "while",
                "for",
                "increment",
                "void",
                "public",
                "switch",
                "instance",
                "double",
                "float",
                "c",
        };

        int question;
        int numberOfQuestions = 14;

        public void PromptQuestions()
        {
            for (int questionNumber = 0; questionNumber <= numberOfQuestions; questionNumber++)
            {
                Clear();
                utility.Yellow();
                int randomNumber = (new Random()).Next(0, numberOfQuestions);
                WriteLine(questions[randomNumber]);
                ResetColor();
                string input = ReadLine();
                if (input.ToLower() == answers[randomNumber])
                {
                    utility.Green();
                    WriteLine("Correct!");
                    ResetColor();
                    player.AddPoint();

                } else
                {
                    utility.Red();
                    WriteLine($"No, the answer is {answers[questionNumber]}");
                    ResetColor();
                }

                WriteLine("Press enter to continue...");
                ReadKey();
                

            }

            Clear();
            PromptMenu();
        }

        public void PracticeMode()
        {
            for (int questionNumber = 0; questionNumber <= numberOfQuestions; questionNumber++)
            {
                Clear();
                utility.Yellow();
                WriteLine(questions[questionNumber]);
                ResetColor();
                WriteLine("Press enter to see the answer");
                ReadKey();
                utility.Yellow();
                WriteLine(answers[questionNumber]);
                ResetColor();
                WriteLine("Press enter to continue...");
                ReadKey();
            }
        }

        public void PromptMenu()
        {
            game.ShowMenu();
            string input = ReadLine();
            if (input == "1")
            {
                PromptQuestions();

            } else if (input == "2")
            {
                player.ShowScore();

            }
            if (input == "3")
            {
                PracticeMode();

            } if (input == "4")
            {
                player.EndTheGame();
                ReadKey();
                Environment.Exit(0);
            } else
            {
                Clear();
                WriteLine("Please pick a valid number");
                PromptMenu();
            }
        }
    }
}
