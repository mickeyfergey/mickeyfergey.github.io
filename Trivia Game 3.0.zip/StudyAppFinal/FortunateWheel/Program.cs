﻿/*
 * By: Mickey Fergus, he/him/his
 * 3/15/2021
 * Study App Final!
 * 
 * 
 */

using System;
using System.IO;
using static System.Console;

namespace FortunateWheel
{
    class Program
    {
        static void Main()
        {
            Execution go = new Execution();
            go.Start();
        }
    }
}
