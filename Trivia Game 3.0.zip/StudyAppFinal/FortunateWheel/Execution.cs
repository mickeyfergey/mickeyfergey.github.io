﻿using System;
using System.IO;
using static System.Console;
namespace FortunateWheel
{
    public class Execution
    {

        // Referenced data here
        Utility u = new Utility();
        double money;
        int boops;

        static string fileQuestions = @"/Users/michaelfergus/Projects/StudyAppFinal/StudyAppFinal/questions.txt";
        public string[] questions = File.ReadAllLines(fileQuestions);

        static string fileAnswers = @"/Users/michaelfergus/Projects/StudyAppFinal/StudyAppFinal/answers.txt";
        public string[] answers = File.ReadAllLines(fileAnswers);

        public void Start()
        {
            Clear();
            // Put title on window
            Title = "Fortunate Wheel!";

            // Welcome player
            u.Yellow();
            WriteLine("[Pat]: Welcome to the Fortunate Wheel! Here's how the game will work!");
            WriteLine("[Pat]: You'll be prompted with a menu like so:");
            u.u();
            u.RC();
            u.Menu();
            u.Yellow();
            u.u();
            WriteLine("[Pat]: Choose an option listed. If you don't, I'm going to make fun of you.");
            WriteLine("[Pat]: Now go make that money!");
            u.RC();
            u.Wait();
            Clear();


            // Loop menu and questions
            bool always = true;
            while (always)
            {
                u.Menu();
                string userInput = ReadLine();
                if (userInput == "1")
                {
                    PromptQuestion();
                    Clear();
                }
                else if (userInput == "2")
                {
                    Clear();
                    u.Yellow();
                    WriteLine($"[Pat]: You have {money:c}!");
                    u.Wait();
                    Clear();
                }
                else if (userInput == "3")
                {
                    EndGame();
                    Clear();
                }
                else
                {
                    Clear();
                    boops++;
                    u.Red();
                    WriteLine("Please press a valid key!");
                    ResetColor();
                }
            }
            Clear();
        }

        // Question methods
        public void PromptQuestion()
        {
            Clear();
            int randomInteger = (new Random()).Next(0, 9);
            double randomMoney = (new Random()).Next(0, 1000);
            u.DarkGray();
            WriteLine("***Wheel spins***");
            WriteLine($"***Wheel lands on {randomMoney:c}***");
            u.Yellow();
            
            WriteLine($"[Pat]: For {randomMoney:c}, {questions[randomInteger]}");
            u.Cyan();
            string input = ReadLine();
            if (input.ToLower() == answers[randomInteger])
            {
                u.Yellow();
                WriteLine("[Pat]: Correct!");
                ResetColor();
                money = money + randomMoney;
            }
            else
            {
                u.Yellow();
                WriteLine($"[Pat]: No, the correct answer is {answers[randomInteger]}");
                ResetColor();
            }
            u.Wait();
        }
        
        public void EndGame()
        {
            Clear();
            u.Yellow();
            WriteLine("[Pat]: Thanks for playing wheel of fortune!");
            WriteLine($"[Pat]: You pressed a wrong key {boops} times!");
            WriteLine("[Pat]: Told you I'd make fun of you for it :)");
            u.u();
            WriteLine($"[Pat]: But anyway, you walked home with {money:c}! Congrats!");
            u.u();
            u.u();
            u.u();
            u.DarkGray();
            WriteLine("Fortunate Wheel, by Mickey Fergus, he/him/his");
            WriteLine("Copyright 2021 or whatever");
            u.Out();
            Environment.Exit(0);
        }

        
    }
}