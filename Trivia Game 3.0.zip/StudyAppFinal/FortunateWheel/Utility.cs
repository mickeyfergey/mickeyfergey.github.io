﻿using System;
using System.IO;
using static System.Console;
namespace FortunateWheel
{
    public class Utility
    {
        // Utility class!

        // Menu stored here!

        public void Menu()
        {
            Yellow();
            WriteLine("==============================");
            Cyan();
            WriteLine("1.) Spin the wheel!");
            WriteLine("2.) Check my money");
            WriteLine("3.) Leave");
            Yellow();
            WriteLine("==============================");
            RC();
        }

        // FUNCTIONALITY METHODS


        // setup the text files

        
        public void u()
        {
            WriteLine();
        }
        public void Out()
        {
            Red();
            WriteLine("The game is over! Press any key to exit the window");
            ReadKey();
            ResetColor();
        }

        public void Wait()
        {
            DarkGray();
            WriteLine("Press any key to continue...");
            ReadKey();
            ResetColor();
            
        }

        // COLOR METHODS

        public void Red()
        {
            ForegroundColor = ConsoleColor.Red;
        }
        public void Yellow()
        {
            ForegroundColor = ConsoleColor.Yellow;
        }
        public void Green()
        {
            ForegroundColor = ConsoleColor.Green;
        }
        public void Blue()
        {
            ForegroundColor = ConsoleColor.Blue;
        }
        public void Purple()
        {
            ForegroundColor = ConsoleColor.DarkMagenta;
        }
        public void White()
        {
            ForegroundColor = ConsoleColor.White;
        }
        public void RC()
        {
            ForegroundColor = ConsoleColor.White;
        }
        public void Black()
        {
            ForegroundColor = ConsoleColor.Black;
        }
        public void Cyan()
        {
            ForegroundColor = ConsoleColor.Cyan;
        }
        public void DarkCyan()
        {
            ForegroundColor = ConsoleColor.DarkCyan;
        }
        public void DarkBlue()
        {
            ForegroundColor = ConsoleColor.DarkBlue;
        }
        public void DarkGray()
        {
            ForegroundColor = ConsoleColor.DarkGray;
        }
        public void DarkGreen()
        {
            ForegroundColor = ConsoleColor.DarkGreen;
        }
        public void DarkRed()
        {
            ForegroundColor = ConsoleColor.DarkRed;
        }
        public void DarkYellow()
        {
            ForegroundColor = ConsoleColor.DarkYellow;
        }
        public void Gray()
        {
            ForegroundColor = ConsoleColor.Gray;
        }
        public void Magenta()
        {
            ForegroundColor = ConsoleColor.Magenta;
        }
    }
}
