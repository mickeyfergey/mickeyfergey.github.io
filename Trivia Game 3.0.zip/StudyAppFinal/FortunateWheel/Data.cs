﻿using System;
using System.IO;
using static System.Console;
namespace StudyAppFinal
{
    public class Data
    {
        

    }
}
